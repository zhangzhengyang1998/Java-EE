/*
Navicat MySQL Data Transfer

Source Server         : zch
Source Server Version : 50506
Source Host           : localhost:3306
Source Database       : demo

Target Server Type    : MYSQL
Target Server Version : 50506
File Encoding         : 65001

Date: 2019-04-30 14:34:07
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `orderdetail`
-- ----------------------------
DROP TABLE IF EXISTS `orderdetail`;
CREATE TABLE `orderdetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` int(11) DEFAULT NULL,
  `cakeid` int(11) DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderdetail
-- ----------------------------
INSERT INTO `orderdetail` VALUES ('1', '1', '1', '1');
INSERT INTO `orderdetail` VALUES ('2', '2', '2', '1');

-- ----------------------------
-- Table structure for `product`
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `discount` int(11) DEFAULT NULL,
  `tag` varchar(1024) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `bigimg` varchar(50) DEFAULT NULL,
  `img1` varchar(50) DEFAULT NULL,
  `img2` varchar(50) DEFAULT NULL,
  `img3` varchar(50) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `digest` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES ('1', 'cake1', '16', '134', '8', null, '4', 'm2.png', '', 'm3.png', 'm4.png', '5', null);
INSERT INTO `product` VALUES ('2', 'cake2', '8', '145', '7', null, '4', 'g2.jpg', null, null, null, null, null);
INSERT INTO `product` VALUES ('3', 'cake3', '45', '234', '9', null, '5', 'g3.png', null, null, null, null, null);
INSERT INTO `product` VALUES ('4', 'cake4', '34', '345', '5', null, '5', 'g4.png', null, null, null, null, null);
INSERT INTO `product` VALUES ('5', 'cake5', '23', '234', '6', null, '4', 'g5.png', null, null, null, null, null);
INSERT INTO `product` VALUES ('6', 'cake6', '12', '123', '5', null, '3', 'g6.png', null, null, null, null, null);
INSERT INTO `product` VALUES ('7', 'cake7', '11', '456', '4', null, '2', 'g7.png', null, null, null, null, null);
INSERT INTO `product` VALUES ('8', 'cake8', '22', '178', '3', null, '4', 'g8.png', null, null, null, null, null);
INSERT INTO `product` VALUES ('9', 'cake9', '33', '189', '2', null, '5', 'g9.png', null, null, null, null, null);
INSERT INTO `product` VALUES ('10', 'cake10', '45', '190', '1', null, '2', 'g10.png', null, null, null, null, null);

-- ----------------------------
-- Table structure for `tbl_common`
-- ----------------------------
DROP TABLE IF EXISTS `tbl_common`;
CREATE TABLE `tbl_common` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mail` varchar(50) DEFAULT NULL,
  `cakeid` int(11) DEFAULT NULL,
  `context` varchar(1024) DEFAULT NULL,
  `com_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tbl_common
-- ----------------------------

-- ----------------------------
-- Table structure for `tbl_order`
-- ----------------------------
DROP TABLE IF EXISTS `tbl_order`;
CREATE TABLE `tbl_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mail` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `ordertime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tbl_order
-- ----------------------------
INSERT INTO `tbl_order` VALUES ('1', '15226502915', '15226502915', '2019-04-24 15:48:05');
INSERT INTO `tbl_order` VALUES ('2', '15226502915', '15226502915', '2019-04-24 16:02:30');

-- ----------------------------
-- Table structure for `tbl_type`
-- ----------------------------
DROP TABLE IF EXISTS `tbl_type`;
CREATE TABLE `tbl_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `parent` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tbl_type
-- ----------------------------
INSERT INTO `tbl_type` VALUES ('1', 'Birthday', null);
INSERT INTO `tbl_type` VALUES ('2', 'Wedding', null);
INSERT INTO `tbl_type` VALUES ('3', 'Special Offers', null);
INSERT INTO `tbl_type` VALUES ('4', 'Store', null);
INSERT INTO `tbl_type` VALUES ('5', 'By Relation', '2');
INSERT INTO `tbl_type` VALUES ('6', 'By Flavour', '2');
INSERT INTO `tbl_type` VALUES ('7', 'By Theme', '2');
INSERT INTO `tbl_type` VALUES ('8', 'Weight', '2');
INSERT INTO `tbl_type` VALUES ('9', 'By Relation', '3');
INSERT INTO `tbl_type` VALUES ('10', 'By Flavour', '3');
INSERT INTO `tbl_type` VALUES ('11', 'By Theme', '3');
INSERT INTO `tbl_type` VALUES ('12', 'Weight', '3');
INSERT INTO `tbl_type` VALUES ('13', 'By Relation', '4');
INSERT INTO `tbl_type` VALUES ('14', 'By Flavour', '4');
INSERT INTO `tbl_type` VALUES ('15', 'By Theme', '4');
INSERT INTO `tbl_type` VALUES ('16', 'Weight', '4');
INSERT INTO `tbl_type` VALUES ('17', 'By Relation', '1');
INSERT INTO `tbl_type` VALUES ('18', 'By Flavour', '1');
INSERT INTO `tbl_type` VALUES ('19', 'By Theme', '1');
INSERT INTO `tbl_type` VALUES ('20', 'Weight', '1');
INSERT INTO `tbl_type` VALUES ('21', 'Friend', '5');
INSERT INTO `tbl_type` VALUES ('22', 'love', '5');
INSERT INTO `tbl_type` VALUES ('23', 'parent', '18');
INSERT INTO `tbl_type` VALUES ('24', 'apple', '17');
INSERT INTO `tbl_type` VALUES ('25', 'red', '12');

-- ----------------------------
-- Table structure for `tbl_user`
-- ----------------------------
DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE `tbl_user` (
  `mail` varchar(50) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `regist` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`mail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tbl_user
-- ----------------------------
INSERT INTO `tbl_user` VALUES ('13695236545', 'xiaoming', '999666', '2019-04-29 00:00:00');
INSERT INTO `tbl_user` VALUES ('15226502915', 'zhangchunhui', '123456', '2019-04-17 00:00:00');
INSERT INTO `tbl_user` VALUES ('15236985632', 'wangwu', '234567', '2019-04-29 00:00:00');
INSERT INTO `tbl_user` VALUES ('15263256485', 'lisi', '147852', '2019-04-29 00:00:00');
INSERT INTO `tbl_user` VALUES ('15863259635', 'xiaoli', '869523', '2019-04-29 00:00:00');
INSERT INTO `tbl_user` VALUES ('15896325475', 'lily', '565656', '2019-04-29 00:00:00');
INSERT INTO `tbl_user` VALUES ('18965236521', 'jack', '666555', '2019-04-29 00:00:00');
