package com.abc.cakeonline.cake.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.abc.cakeonline.cake.service.CakeDetailService;
import com.abc.cakeonline.entity.Cake;
import com.abc.cakeonline.entity.User;
import com.abc.cakeonline.hdfs.write.WriteFile;



@Controller
public class CakeDetailController {
	@Resource
	private CakeDetailService cakeDetailService;
	private static Logger log = LoggerFactory.getLogger(CakeDetailController.class);

	@RequestMapping("/CakeDetailServlet")
	public String showDetail(@RequestParam(value = "id", required = false) String requestId,
			HttpServletRequest request) throws IOException {
		int id = 0;
		id = Integer.parseInt(requestId);
		Cake cake = this.cakeDetailService.findId(id);
		request.setAttribute("cakedetail", cake);
		
		User user=(User) request.getSession().getAttribute("u");
		SimpleDateFormat sfDateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String timstamp=sfDateFormat.format(new Date());
		String mail=user.getMail();
		if(mail==null||mail.equals(" ")) {
			mail="666";
		}
		log.info(mail+" "+id+" "+timstamp+" "+cake.getLevel());
		WriteFile.WriteToHdfs();
		return "single";

	}

}
