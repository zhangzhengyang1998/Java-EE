package com.abc.cakeonline.hdfs.write;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

public class WriteFile {

	//����־���ļ�����д��hdfs
	public static void WriteToHdfs() throws IOException {
		Configuration conf = new Configuration();
		conf.set("fs.default.name", "hdfs://192.168.56.12:9000");
		conf.set("fs.hdfs.impl", "org.apache.hadoop.hdfs.DistributedFileSystem");
		conf.set("dfs.client.block.write.replace-datanode-on-failure.policy", "NEVER");
		FileSystem hdfs = FileSystem.get(conf);
		FSDataOutputStream fdos=hdfs.create(new Path("/2016bigdata/log.txt"));
		BufferedReader br=new BufferedReader(new FileReader(new File("d://testFile.log")));
		String string=null;
		while((string =br.readLine())!=null) {
			fdos.write(string.getBytes());
		}
		fdos.close();
	}

}
