package com.abc.cakeonline.order.dao;

import javax.annotation.Resource;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Durability;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.abc.cakeonline.entity.Order;
@Repository
public class OrderDao {

	@Resource
	private SessionFactory sessionFactory;

	// �򶩵����������������ͬʱ��������
	public void insertOrder(Order order) {
		Session session=this.sessionFactory.getCurrentSession();
		session.save(order);
	}

	//����д��hbase
	public void putToTable(String mail,String timstamp,int cakeId,int count,int orderId){
		try{
			Configuration conf=HBaseConfiguration.create();
			HTable table = new HTable(conf, "tbl_table");
			Put put=new Put(Bytes.toBytes("id1"));
			put.add(Bytes.toBytes("orderId"), Bytes.toBytes("mail"), Bytes.toBytes(mail));
			put.add(Bytes.toBytes("orderId"),Bytes.toBytes("timeStamp"),Bytes.toBytes(timstamp));
			
			put.add(Bytes.toBytes("orderDetailId"),Bytes.toBytes("orderId"),Bytes.toBytes(orderId));
			put.add(Bytes.toBytes("orderDetailId"),Bytes.toBytes("cakeId"),Bytes.toBytes(cakeId));
			put.add(Bytes.toBytes("orderDetailId"),Bytes.toBytes("count"),Bytes.toBytes(count));
			put.setDurability(Durability.ASYNC_WAL);	
			table.put(put);
			table.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}


}
